const readline = require('readline');
const parser = require("./prueba"); 
const analyzeSemantics = require("./semantic");
const lex = require('./lexer');
const compile = require("./compiler");

const rl = readline.createInterface({
    input: process.stdin,
    output: process.stdout
});


rl.question('Ingresa la cadena de texto: ', (input) => {
    const tokens = lex(input);

    console.log("Tokens Generados:");
    tokens.forEach((token, index) => {
        console.log(`${index + 1}: ${token.type} (${token.value})`);
    });
    
    try {
        const ast = parser.parse(input);
        //console.log("AST Generado:");
        //console.log(JSON.stringify(ast, null, 2));

        const { errors: semanticErrors, variablesStatus } = analyzeSemantics(ast);
        if (semanticErrors.length > 0) {
            console.error("Errores Semánticos encontrados:");
            semanticErrors.forEach(error => console.error(error));
        } else {
            console.log("Codigo correcto, no se encontraron errores semánticos.");
            const compiledCode = compile(ast, variablesStatus);
            console.log("Código Compilado:\n", compiledCode);
            let output = captureOutput(() => eval(compiledCode));
            console.log("Resultado del código:\n", output);
        }
    } catch (error) {
        console.error("Error durante el análisis:", error.message);
    }finally {
        rl.close(); 
    }
});

function captureOutput(callback) {
    const oldLog = console.log;
    let output = [];
    console.log = (message) => {
        output.push(message);
    };

    callback();

    console.log = oldLog; 
    return output.join("\n");
}